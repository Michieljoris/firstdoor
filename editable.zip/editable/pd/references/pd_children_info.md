2. Children’s Health and Safety
 - NQS 2.3: Each child is protected
 - NQS 2.3.4: Action is taken to respond to every child at risk of abuse and/or neglect.

Reference	
Australian Children’s Education and Care Quality Authority. (2011). Guide to the National Quality Standard.
Retrieved from:
<http://acecqa.gov.au/storage/2-DE_03_National%20Quality%20Standard_v8_Secn1.pdf>
